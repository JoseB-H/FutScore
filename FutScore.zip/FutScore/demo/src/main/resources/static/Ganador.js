
  const nombres = ['Carlos A.', 'María R.', 'José P.', 'Ana L.', 'Miguel T.', 'Lucía S.', 'Pedro Q.', 'Sofía D.'];
  const montos = [80, 120, 95, 150, 60, 100, 130, 200];

  function mostrarGanadorAleatorio() {
    const anuncio = document.getElementById("anuncioIzquierdo");
    const mensaje = document.getElementById("mensajeGanador");

    const nombre = nombres[Math.floor(Math.random() * nombres.length)];
    const monto = montos[Math.floor(Math.random() * montos.length)];

    mensaje.textContent = `${nombre} ganó S/${monto} apostando a una fija.`;

    anuncio.style.display = "block";

    setTimeout(() => {
      anuncio.style.display = "none";
    }, 8000);
  }

  document.addEventListener("DOMContentLoaded", () => {
    mostrarGanadorAleatorio();
    setInterval(mostrarGanadorAleatorio, 180000);
  });

  document.addEventListener("DOMContentLoaded", () => {
    const botonDesdeAnuncio = document.getElementById("btnAbrirLoginDesdeAnuncio");

    if (botonDesdeAnuncio) {
      botonDesdeAnuncio.addEventListener("click", function (e) {
        e.preventDefault();

        const contenedor = document.getElementById("login-modal-container");

        if (!document.getElementById("modalLogin")) {
          fetch("modales/login.html")
            .then(res => res.text())
            .then(html => {
              contenedor.innerHTML = html;
              setTimeout(() => {
                const loginModal = new bootstrap.Modal(document.getElementById('modalLogin'));
                loginModal.show();
              }, 100);
            });
        } else {
          const loginModal = new bootstrap.Modal(document.getElementById('modalLogin'));
          loginModal.show();
        }
      });
    }
  });