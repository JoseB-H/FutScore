function cerrarSesion() {
  fetch("/logout", {
    method: "POST",
    credentials: "include"
  })
  .then(() => {
    window.location.href = "/";
  })
  .catch(err => {
    console.error("Error al cerrar sesión", err);
    alert("Error al cerrar sesión");
  });
}

function verPerfil() {
  alert("Aquí iría tu lógica para ver perfil (luego puedes hacer window.location.href = '/perfil.html').");
}
