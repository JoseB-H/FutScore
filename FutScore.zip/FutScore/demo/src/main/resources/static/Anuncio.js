document.addEventListener("DOMContentLoaded", function () {
  const popup = document.getElementById("popupPromo");
  const btnCerrar = document.getElementById("btnCerrarPopup");
  const imgPromo = document.getElementById("imgPromo");

  const logueado = /*[[${#request.remoteUser != null}]]*/ false;

  if (!logueado) {
    popup.style.display = "flex";
  }

  btnCerrar.addEventListener("click", function () {
    popup.style.display = "none";
  });

  imgPromo.addEventListener("click", function () {
    popup.style.display = "none";

    const contenedor = document.getElementById("login-modal-container");
    if (!document.getElementById("modalLogin")) {
      fetch("modales/login.html")
        .then(res => res.text())
        .then(html => {
          contenedor.innerHTML = html;
          setTimeout(() => {
            const loginModal = new bootstrap.Modal(document.getElementById('modalLogin'));
            loginModal.show();
          }, 100);
        });
    } else {
      const loginModal = new bootstrap.Modal(document.getElementById('modalLogin'));
      loginModal.show();
    }
  });
});

