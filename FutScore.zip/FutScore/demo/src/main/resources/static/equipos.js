 // lista de los equipos/ligas en la barra de busqueda ya redireccionado Aarron chupa pija
 const equipos = [
    { nombre: "Barcelona", imagen: "/img/barcelona.png", url: "/barcelona.html" },
    { nombre: "Inter Milan", imagen: "/img/inter-milan.png", url: "/equipo/inter-milan.html" },
    { nombre: "Al-Nassr", imagen: "/img/al-nassr.png", url: "/equipo/al-nassr.html" },
    { nombre: "Al-Hilal", imagen: "/img/al-hilal.png", url: "/equipo/al-hilal.html" },
    { nombre: "Alianza", imagen: "/img/alianza-lima.png", url: "/equipo/alianza-lima.html" },
    { nombre: "Universitario", imagen: "/img/u.png", url: "/equipo/u.html" },
    { nombre: "Arsenal", imagen: "/img/arsenal.png", url: "/equipo/arsenal.html" },
    { nombre: "PSG", imagen: "/img/psg.png", url: "/equipo/psg.html" },
    { nombre: "Sporting Cristal", imagen: "/img/sporting-cristal.png", url: "/equipo/sporting-cristal.html" },
    { nombre: "Deportivo Garcilaso", imagen: "/img/deportivo-garcilaso.png", url: "/equipo/deportivo-garcilaso.html" },
    { nombre: "Liverpool", imagen: "/img/liverpool.png", url: "/equipo/liverpool.html" },
    { nombre: "Bayer Munich", imagen: "/img/bayer-munich.png", url: "/equipo/bayer-munich.html" },
    { nombre: "Manchester United", imagen: "/img/manchester-united.png", url: "/equipo/manchester-united.html" },
    { nombre: "Manchester City", imagen: "/img/manchester-city.png", url: "/equipo/manchester-city.html" },
    { nombre: "Napoli", imagen: "/img/napoli.png", url: "/equipo/napoli.html" },
    //ligas
    { nombre: "UEFA Champions League", imagen: "/img/champions-league.png", url: "/ligas.html" },
    { nombre: "Premier League", imagen: "/img/premier-league.png", url: "/ligas.html" },
    { nombre: "Liga 1", imagen: "/img/liga1.png", url: "/ligas.html" },
    { nombre: "Serie A", imagen: "/img/serieA.png", url: "/ligas.html" },
    { nombre: "La Eurocopa", imagen: "/img/eurocopa.png", url: "/ligasAparte/eurocopa.html" },
    { nombre: "Bundesliga", imagen: "/img/bundesliga.png", url: "/ligasAparte/bundesliga.html" },
    { nombre: "La Liga", imagen: "/img/laliga.png", url: "/ligasAparte/laliga.html" },
    { nombre: "CONMEBOL Libertadores", imagen: "/img/conmebolLibertadores.png", url: "/ligasAparte/libertadores.html" },
  ];

