function handleLogin() {
  const email = document.getElementById("correo").value;
  const password = document.getElementById("password").value;

  fetch("http://localhost:8080/api/usuarios/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
    credentials: "include"  
  })
  .then(res => {
    if (res.ok) {
      const modalLogin = bootstrap.Modal.getInstance(document.getElementById('modalLogin'));
      if (modalLogin) {
        modalLogin.hide();
      }
      setTimeout(() => {
        window.location.href = "/apuestas";   
      }, 300);
    } else {
      res.text().then(msg => alert(msg));
    }
  })
  .catch(err => {
    console.error(err);
    alert("Error en el servidor");
  });
}
