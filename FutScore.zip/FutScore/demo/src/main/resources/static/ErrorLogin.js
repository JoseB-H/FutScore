
document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  if (params.get("error") === "unauthorized") {
    const msgDiv = document.getElementById("mensajeError");
    msgDiv.textContent = "Debes iniciar sesión para acceder a Apuestas.";
    msgDiv.style.display = "block";
  }
});

