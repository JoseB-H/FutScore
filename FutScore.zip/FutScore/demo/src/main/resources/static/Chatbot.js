document.getElementById("chatbot-toggle").addEventListener("click", function() {
    const chatbotWindow = document.getElementById("chatbot-window");
    chatbotWindow.style.display = chatbotWindow.style.display === "none" ? "flex" : "none";
});

document.getElementById("chatbot-send").addEventListener("click", function() {
    const input = document.getElementById("chatbot-input");
    const message = input.value.trim().toLowerCase();
    if (!message) return;

    const messagesDiv = document.getElementById("chatbot-messages");
    messagesDiv.innerHTML += `<div style="margin-bottom: 5px;"><strong>Tú:</strong> ${input.value}</div>`;

    let respuesta = "Alianza Lima es el mejor equipo de la Liga 1.";

    if (message.includes("sudamericana")) {
        respuesta = "¡Alianza Lima ganará la Sudamericana!";
    } else if (message.includes("gremio")) {
        respuesta = "¡Claro que sí! Alianza Lima ganará contra Gremio.";
    }

    messagesDiv.innerHTML += `<div style="margin-bottom: 10px;"><strong>Bot:</strong> ${respuesta}</div>`;

    input.value = "";
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});
