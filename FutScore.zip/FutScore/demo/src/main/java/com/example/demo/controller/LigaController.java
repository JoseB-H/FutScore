package com.example.demo.controller;

import com.example.demo.model.Equipo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/liga")
public class LigaController {

    @GetMapping("/")
    public String mostrarInicio() {
        return "index"; 
    }

    @GetMapping("/{nombreLiga}")
    public String mostrarLiga(@PathVariable String nombreLiga, Model model) {
        List<Equipo> equipos = new ArrayList<>();

        switch (nombreLiga.toLowerCase()) {
            case "champions-league":
                equipos = List.of(
                        new Equipo(1, "/img/liverpool.png", "Liverpool", 38, 25, 9, 4, 86, 41, 45, 84),
                        new Equipo(2, "/img/barcelona.png", "Barcelona", 38, 89, 38, 26, 6, 6, 88, 43),
                        new Equipo(3, "/img/arsenal.png", "Arsenal", 38, 82, 24, 10, 4, 75, 32, 82),
                        new Equipo(4, "/img/inter-milan.png", "Inter Milan", 38, 68, 20, 8, 10, 61, 41, 67),
                        new Equipo(5, "/img/tottenham.png", "Tottenham", 38, 66, 19, 9, 10, 63, 45, 66),
                        new Equipo(6, "/img/chelsea.png", "Chelsea", 38, 63, 18, 9, 11, 57, 43, 63),
                        new Equipo(7, "/img/newcastle.png", "Newcastle", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(8, "/img/manchester-united.png", "Manchester United", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(9, "/img/west-ham.png", "West Ham", 38, 52, 15, 7, 16, 53, 60, 52),
                        new Equipo(10, "/img/crystal-palace.png", "Crystal Palace", 38, 49, 13, 10, 15, 45, -5, 49),
                        new Equipo(11, "/img/brighton.png", "Brighton", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(12, "/img/bournemouth.png", "Bournemouth", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(13, "/img/fulham.png", "Fulham", 38, 47, 13, 8, 17, 40, -15, 47),
                        new Equipo(14, "/img/wolves.png", "Wolves", 38, 46, 12, 10, 16, 40, -15, 46),
                        new Equipo(15, "/img/everton.png", "Everton", 38, 40, 11, 7, 20, 35, -25, 40),
                        new Equipo(16, "/img/brentford.png", "Brentford", 38, 39, 10, 9, 19, 40, -20, 39),
                        new Equipo(17, "/img/nottingham-forest.png", "Nottingham Forest", 38, 32, 9, 5, 24, 40, -30, 32),
                        new Equipo(18, "/img/luton-town.png", "Luton Town", 38, 26, 7, 5, 26, 30, -40, 26),
                        new Equipo(19, "/img/burnley.png", "Burnley", 38, 24, 18, 6, 14, 30, -40, 24),
                        new Equipo(20, "/img/sheffield-united.png", "Sheffield United", 38, 16, 5, 1, 32, 78, -46, 16));
                break;
            case "premier-league":
                equipos = List.of(
                        new Equipo(1, "/img/manchester-city.png", "Manchester City", 38, 25, 9, 4, 86, 41, 45, 84),
                        new Equipo(2, "/img/arsenal.png", "Arsenal", 38, 89, 38, 26, 6, 6, 88, 43),
                        new Equipo(3, "/img/liverpool.png", "Liverpool", 38, 82, 24, 10, 4, 75, 32, 82),
                        new Equipo(4, "/img/aston-villa.png", "Aston Villa", 38, 68, 20, 8, 10, 61, 41, 67),
                        new Equipo(5, "/img/tottenham.png", "Tottenham", 38, 66, 19, 9, 10, 63, 45, 66),
                        new Equipo(6, "/img/chelsea.png", "Chelsea", 38, 63, 18, 9, 11, 57, 43, 63),
                        new Equipo(7, "/img/newcastle.png", "Newcastle", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(8, "/img/manchester-united.png", "Manchester United", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(9, "/img/west-ham.png", "West Ham", 38, 52, 15, 7, 16, 53, 60, 52),
                        new Equipo(10, "/img/crystal-palace.png", "Crystal Palace", 38, 49, 13, 10, 15, 45, -5, 49),
                        new Equipo(11, "/img/brighton.png", "Brighton", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(12, "/img/bournemouth.png", "Bournemouth", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(13, "/img/fulham.png", "Fulham", 38, 47, 13, 8, 17, 40, -15, 47),
                        new Equipo(14, "/img/wolves.png", "Wolves", 38, 46, 12, 10, 16, 40, -15, 46),
                        new Equipo(15, "/img/everton.png", "Everton", 38, 40, 11, 7, 20, 35, -25, 40),
                        new Equipo(16, "/img/brentford.png", "Brentford", 38, 39, 10, 9, 19, 40, -20, 39),
                        new Equipo(17, "/img/nottingham-forest.png", "Nottingham Forest", 38, 32, 9, 5, 24, 40, -30,32),
                        new Equipo(18, "/img/luton-town.png", "Luton Town", 38, 26, 7, 5, 26, 30, -40, 26),
                        new Equipo(19, "/img/burnley.png", "Burnley", 38, 24, 18, 6, 14, 30, -40, 24),
                        new Equipo(20, "/img/sheffield-united.png", "Sheffield United", 38, 16, 5, 1, 32, 78, -46, 16));
                break;
            case "bundesliga":
                equipos = List.of(
                        new Equipo(1, "/img/bayern-munich.png", "Bayern Munich", 34, 77, 24, 5, 5, 92, 36, 56),
                        new Equipo(2, "/img/borussia-dortmund.png", "Borussia Dortmund", 34, 69, 21, 6, 7, 85, 50, 35),
                        new Equipo(3, "/img/rb-leipzig.png", "RB Leipzig", 34, 64, 19, 7, 8, 64, 36, 28),
                        new Equipo(4, "/img/bayer-leverkusen.png", "Bayer Leverkusen", 34, 58, 17, 7, 10, 65, 50, 15),
                        new Equipo(5, "/img/union-berlin.png", "Union Berlin", 34, 57, 15, 12, 7, 50, 40, 10),
                        new Equipo(6, "/img/sc-freiburg.png", "SC Freiburg", 34, 55, 15, 10, 9, 52, 45, 7),
                        new Equipo(7, "/img/1-fc-koln.png", "1. FC Köln", 34, 52, 14, 10, 10, 50, 48, 2),
                        new Equipo(8, "/img/mainz-05.png", "Mainz 05", 34, 46, 12, 10, 12, 40, 40, 0),
                        new Equipo(9, "/img/hertha-berlin.png", "Hertha Berlin", 34, 42, 11, 9, 14, 40, 50, -10),
                        new Equipo(10, "/img/crystal-palace.png", "Crystal Palace", 38, 49, 13, 10, 15, 45, -5, 49),
                        new Equipo(11, "/img/brighton.png", "Brighton", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(12, "/img/bournemouth.png", "Bournemouth", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(13, "/img/fulham.png", "Fulham", 38, 47, 13, 8, 17, 40, -15, 47),
                        new Equipo(14, "/img/wolves.png", "Wolves", 38, 46, 12, 10, 16, 40, -15, 46),
                        new Equipo(15, "/img/everton.png", "Everton", 38, 40, 11, 7, 20, 35, -25, 40),
                        new Equipo(16, "/img/brentford.png", "Brentford", 38, 39, 10, 9, 19, 40, -20, 39),
                        new Equipo(17, "/img/nottingham-forest.png", "Nottingham Forest", 38, 32, 9, 5, 24, 40, -30,
                                32),
                        new Equipo(18, "/img/luton-town.png", "Luton Town", 38, 26, 7, 5, 26, 30, -40, 26),
                        new Equipo(19, "/img/burnley.png", "Burnley", 38, 24, 18, 6, 14, 30, -40, 24),
                        new Equipo(20, "/img/sheffield-united.png", "Sheffield United", 38, 16, 5, 1, 32, 78, -46, 16));
                break;
            case "laliga":
                equipos = List.of(
                        new Equipo(1, "/img/barcelona.png", "Barcelona", 38, 25, 9, 4, 86, 41, 45, 84),
                        new Equipo(2, "/img/real-madrid.png", "Real Madrid", 38, 89, 38, 26, 6, 6, 88, 43),
                        new Equipo(3, "/img/liverpool.png", "Liverpool", 38, 82, 24, 10, 4, 75, 32, 82),
                        new Equipo(4, "/img/aston-villa.png", "Aston Villa", 38, 68, 20, 8, 10, 61, 41, 67),
                        new Equipo(5, "/img/tottenham.png", "Tottenham", 38, 66, 19, 9, 10, 63, 45, 66),
                        new Equipo(6, "/img/chelsea.png", "Chelsea", 38, 63, 18, 9, 11, 57, 43, 63),
                        new Equipo(7, "/img/newcastle.png", "Newcastle", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(8, "/img/manchester-united.png", "Manchester United", 38, 60, 17, 9, 12, 55, 48, 60),
                        new Equipo(9, "/img/west-ham.png", "West Ham", 38, 52, 15, 7, 16, 53, 60, 52),
                        new Equipo(10, "/img/crystal-palace.png", "Crystal Palace", 38, 49, 13, 10, 15, 45, -5, 49),
                        new Equipo(11, "/img/brighton.png", "Brighton", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(12, "/img/bournemouth.png", "Bournemouth", 38, 48, 13, 9, 16, 40, -10, 48),
                        new Equipo(13, "/img/fulham.png", "Fulham", 38, 47, 13, 8, 17, 40, -15, 47),
                        new Equipo(14, "/img/wolves.png", "Wolves", 38, 46, 12, 10, 16, 40, -15, 46),
                        new Equipo(15, "/img/everton.png", "Everton", 38, 40, 11, 7, 20, 35, -25, 40),
                        new Equipo(16, "/img/brentford.png", "Brentford", 38, 39, 10, 9, 19, 40, -20, 39),
                        new Equipo(17, "/img/nottingham-forest.png", "Nottingham Forest", 38, 32, 9, 5, 24, 40, -30,
                                32),
                        new Equipo(18, "/img/luton-town.png", "Luton Town", 38, 26, 7, 5, 26, 30, -40, 26),
                        new Equipo(19, "/img/burnley.png", "Burnley", 38, 24, 18, 6, 14, 30, -40, 24),
                        new Equipo(20, "/img/sheffield-united.png", "Sheffield United", 38, 16, 5, 1, 32, 78, -46, 16));
                break;
            case "serie-a":
                equipos = List.of(
                        new Equipo(1, "/img/inter.png", "Inter", 38, 87, 26, 9, 3, 78, 30, 87),
                        new Equipo(2, "/img/juventus.png", "Juventus", 38, 78, 23, 9, 6, 70, 30, 78),
                        new Equipo(3, "/img/napoli.png", "Napoli", 38, 76, 22, 10, 6, 65, 30, 76),
                        new Equipo(4, "/img/ac-milan.png", "AC Milan", 38, 74, 22, 8, 8, 60, 30, 74),
                        new Equipo(5, "/img/as-roma.png", "AS Roma", 38, 70, 20, 10, 8, 55, 30, 70),
                        new Equipo(6, "/img/lazio.png", "Lazio", 38, 68, 20, 8, 10, 50, 30, 68),
                        new Equipo(7, "/img/atalanta.png", "Atalanta", 38, 66, 19, 9, 10, 55, 30, 66),
                        new Equipo(8, "/img/sassuolo.png", "Sassuolo", 38, 60, 18, 6, 14, 50, 30, 60),
                        new Equipo(9, "/img/fiorentina.png", "Fiorentina", 38, 58, 17, 7, 14, 45, 30, 58),
                        new Equipo(10, "/img/torino.png", "Torino", 38, 55, 16, 7, 15, 40, 30, 55),
                        new Equipo(11, "/img/sampdoria.png", "Sampdoria", 38, 50, 15, 5, 18, 35, 30, 50),
                        new Equipo(12, "/img/bologna.png", "Bologna", 38, 48, 14, 6, 18, 40, 30, 48),
                        new Equipo(13, "/img/udinese.png", "Udinese", 38, 46, 13, 7, 18, 35, 30, 46),
                        new Equipo(14, "/img/cagliari.png", "Cagliari", 38, 44, 12, 8, 18, 30, 30, 44),
                        new Equipo(15, "/img/genoa.png", "Genoa", 38, 42, 11, 10, 17, 30, 30, 42),
                        new Equipo(16, "/img/salernitana.png", "Salernitana", 38, 40, 10, 10, 18, 30, 30, 40),
                        new Equipo(17, "/img/lecce.png", "Lecce", 38, 38, 9, 11, 18, 30, 30, 38),
                        new Equipo(18, "/img/empoli.png", "Empoli", 38, 36, 8, 12, 18, 30, 30, 36),
                        new Equipo(19, "/img/monza.png", "Monza", 38, 34, 7, 14, 17, 30, 30, 34),
                        new Equipo(20, "/img/spal.png", "SPAL", 38, 32, 6, 16, 16, 30, 30, 32));
                break;
            default:
                model.addAttribute("error", "Liga no encontrada.");
                return "liga-no-encontrada"; // puedes hacer una vista simple de error
        }

        model.addAttribute("nombreLiga", nombreLiga);
        model.addAttribute("equipos", equipos);
        return "liga";
    }

}
