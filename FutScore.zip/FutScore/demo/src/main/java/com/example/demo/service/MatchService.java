package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.repository.MatchRepository;
import com.example.demo.model.Match;

import java.util.List;

@Service
public class MatchService {
    private final MatchRepository repository;

    public MatchService(MatchRepository repository) {
        this.repository = repository;
    }

    public List<Match> obtenerTodos() {
        return repository.findAll();
    }

    public Match buscarPorId(Long id) {
        return repository.findById(id);
    }
}
