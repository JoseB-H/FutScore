package com.example.demo.controller;

import com.example.demo.model.Usuario;
import com.example.demo.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PerfilController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/perfil")
    public String perfil(Model model, HttpSession session) {
        String email = (String) session.getAttribute("usuarioLogueado");

        if (email == null) {
            model.addAttribute("error", "Debes iniciar sesión para ver tu perfil");
            return "perfil";
        }

        Optional<Usuario> usuarioOpt = usuarioService.buscarPorEmail(email);
        if (usuarioOpt.isEmpty()) {
            model.addAttribute("error", "Usuario no encontrado");
            return "perfil";
        }

        model.addAttribute("usuario", usuarioOpt.get());
        return "perfil";
    }

}
