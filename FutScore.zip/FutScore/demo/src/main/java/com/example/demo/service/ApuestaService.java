package com.example.demo.service;

import com.example.demo.model.ApuestaUsuario;
import com.example.demo.model.Usuario;
import com.example.demo.repository.ApuestaUsuarioRepository;
import com.example.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApuestaService {

    @Autowired
    private ApuestaUsuarioRepository apuestaRepo;

    @Autowired
    private UsuarioRepository usuarioRepo;

    public ApuestaUsuario registrarApuesta(Long usuarioId, ApuestaUsuario apuesta) {
        Usuario usuario = usuarioRepo.findById(usuarioId)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        apuesta.setUsuario(usuario);
        return apuestaRepo.save(apuesta);
    }
}