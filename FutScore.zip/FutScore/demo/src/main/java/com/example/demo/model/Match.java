package com.example.demo.model;

public class Match {
    private Long id;
    private String teamA;
    private String teamB;
    private String date;
    private Double oddsA;
    private Double oddsB;
    private Double oddsDraw;
    private String estado; 
    private String competencia; 

    // Constructor vacío (necesario para frameworks y pruebas)
    public Match() {
    }

    // Constructor con todos los campos
    public Match(Long id, String teamA, String teamB, String date, Double oddsA, Double oddsDraw, Double oddsB, String estado, String competencia) {
        this.id = id;
        this.teamA = teamA;
        this.teamB = teamB;
        this.date = date;
        this.oddsA = oddsA;
        this.oddsDraw = oddsDraw;
        this.oddsB = oddsB;
        this.estado = estado;
        this.competencia = competencia;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTeamA() {
        return teamA;
    }

    public void setTeamA(String teamA) {
        this.teamA = teamA;
    }

    public String getTeamB() {
        return teamB;
    }

    public void setTeamB(String teamB) {
        this.teamB = teamB;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Double getOddsA() {
        return oddsA;
    }

    public void setOddsA(Double oddsA) {
        this.oddsA = oddsA;
    }

    public Double getOddsB() {
        return oddsB;
    }

    public void setOddsB(Double oddsB) {
        this.oddsB = oddsB;
    }

    public Double getOddsDraw() {
        return oddsDraw;
    }

    public void setOddsDraw(Double oddsDraw) {
        this.oddsDraw = oddsDraw;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCompetencia() {
        return competencia;
    }

    public void setCompetencia(String competencia) {
        this.competencia = competencia;
    }

}
