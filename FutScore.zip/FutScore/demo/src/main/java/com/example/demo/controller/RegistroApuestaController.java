package com.example.demo.controller;

import com.example.demo.model.ApuestaUsuario;
import com.example.demo.service.ApuestaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/apuestas")
@CrossOrigin(origins = "*")
public class RegistroApuestaController {

    @Autowired
    private ApuestaService apuestaService;

    @PostMapping("/registrar")
    public ResponseEntity<?> registrarApuesta(@RequestParam Long usuarioId, @RequestBody ApuestaUsuario apuesta) {
        try {
            ApuestaUsuario nuevaApuesta = apuestaService.registrarApuesta(usuarioId, apuesta);
            return ResponseEntity.ok(nuevaApuesta);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
