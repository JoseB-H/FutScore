package com.example.demo.controller;

import com.example.demo.model.Usuario;
import com.example.demo.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import java.util.Collections;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @ResponseBody
    @PostMapping("/registrar")
    public ResponseEntity<?> registrar(@RequestBody Usuario usuario) {
        if (usuarioService.emailYaRegistrado(usuario.getEmail())) {
            return ResponseEntity.badRequest().body("El correo ya está registrado.");
        }
        usuario.setUsername(usuario.getEmail().split("@")[0]); 
        usuarioService.registrar(usuario);
        return ResponseEntity.ok("Usuario registrado correctamente");
    }

    @ResponseBody
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuario, HttpSession session) {
        Optional<Usuario> encontrado = usuarioService.buscarPorEmail(usuario.getEmail());

        if (encontrado.isEmpty()) {
            return ResponseEntity.status(401).body("Correo no registrado");
        }

        Usuario usuarioBD = encontrado.get();

        if (!passwordEncoder.matches(usuario.getPassword(), usuarioBD.getPassword())) {
            return ResponseEntity.status(401).body("Contraseña incorrecta");
        }

        session.setAttribute("usuarioLogueado", usuarioBD.getEmail());

        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                usuarioBD.getEmail(), null, Collections.emptyList());
        SecurityContextHolder.getContext().setAuthentication(authToken);

        session.setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());

        return ResponseEntity.ok("Login exitoso");
    }
}
