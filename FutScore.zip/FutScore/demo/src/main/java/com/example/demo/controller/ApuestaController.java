package com.example.demo.controller;

import com.example.demo.model.Apuesta;
import com.example.demo.model.Usuario;
import com.example.demo.repository.ApuestaRepository;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.MatchService;
import java.security.Principal;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ApuestaController {

    private final MatchService service;
    private final ApuestaRepository apuestaRepository;
    private final UsuarioRepository usuarioRepository;

    public ApuestaController(MatchService service, ApuestaRepository apuestaRepository,
            UsuarioRepository usuarioRepository) {
        this.service = service;
        this.apuestaRepository = apuestaRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // Muestra lista de partidos disponibles para apostar
    @GetMapping("/apuestas")
    public String mostrarApuestas(Model model) {
        model.addAttribute("partidos", service.obtenerTodos());
        return "apuestas"; 
    }

    @GetMapping("/apostar/{id}")
    public String apostarFormulario(@PathVariable Long id, Model model) {
        model.addAttribute("partido", service.buscarPorId(id));
        return "formulario-apuesta"; 
    }

    @GetMapping("/formulario-apuesta")
    public String formularioGeneral(Model model) {
        model.addAttribute("partidos", service.obtenerTodos());
        return "formulario-apuesta";
    }

    // Procesa la apuesta enviada desde el formulario que valida en la base de datos
    @PostMapping("/confirmar-apuesta")
    public String confirmarApuesta(
            @RequestParam Long matchId,
            @RequestParam String resultado,
            @RequestParam String golesTotales,
            @RequestParam String tarjetasAmarillas,
            @RequestParam String penal,
            @RequestParam String corners,
            @RequestParam String ambosMarcan,
            @RequestParam String quienAnotaPrimero,
            @RequestParam Double monto,
            Principal principal) {

        Apuesta apuesta = new Apuesta();
        apuesta.setMatchId(matchId);
        apuesta.setResultado(resultado);
        apuesta.setGolesTotales(golesTotales);
        apuesta.setTarjetasAmarillas(tarjetasAmarillas);
        apuesta.setPenal(penal.equalsIgnoreCase("si"));
        apuesta.setCorners(corners);
        apuesta.setAmbosMarcan(ambosMarcan.equalsIgnoreCase("si"));
        apuesta.setQuienAnotaPrimero(quienAnotaPrimero);
        apuesta.setMonto(monto);

        // Obtén el usuario autenticado usando Optional del repository
        Usuario usuario = usuarioRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        apuesta.setUsuario(usuario);

        apuestaRepository.save(apuesta);

        return "redirect:/historial";
    }

    // Muestra historial de apuestas guardadas de cada usuario
    @GetMapping("/historial")
    public String verHistorial(Model model, Principal principal) {
        Usuario usuario = usuarioRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        List<Apuesta> apuestas = apuestaRepository.findByUsuario(usuario);
        model.addAttribute("apuestas", apuestas);
        return "historial";
    }

    // Elimina una apuesta del historial
    @PostMapping("/eliminar-apuesta/{id}")
    public String eliminarApuesta(@PathVariable Long id, Principal principal) {
        Usuario usuario = usuarioRepository.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Apuesta apuesta = apuestaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Apuesta no encontrada"));
        if (!apuesta.getUsuario().getId().equals(usuario.getId())) {
            throw new RuntimeException("No puedes eliminar apuestas de otros usuarios");
        }
        apuestaRepository.deleteById(id);
        return "redirect:/historial";
    }
}
