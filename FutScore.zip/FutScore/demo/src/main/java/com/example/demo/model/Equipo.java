package com.example.demo.model;

public class Equipo {
    private int posicion; 
    private String imagen;
    private String nombre;
    private int partidosJugados;
    private int ganados;
    private int empate;
    private int perdidos;
    private int golesFinales;
    private int golesContra;
    private int DifGoles;
    private int puntos;

    // Constructor, getters y setters
    public Equipo(int posicion, String imagen, String nombre, int partidosJugados, int ganados, 
    int empate, int perdidos, int golesFinales, int golesContra, int difGoles, int puntos) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.posicion = posicion;
        this.partidosJugados = partidosJugados;
        this.ganados = ganados;
        this.empate = empate;
        this.perdidos = perdidos;
        this.golesFinales = golesFinales;
        this.golesContra = golesContra;
        this.DifGoles = difGoles;
        this.puntos = puntos;
    }

    // Getters
    public int getPosicion() { return posicion; }
    public String getNombre() { return nombre; }
    public String getImagen() { return imagen; }
    public int getPartidosJugados() { return partidosJugados; }
    public int getGanados() { return ganados; }
    public int getEmpate() { return empate; }
    public int getPerdidos() { return perdidos; }
    public int getGolesFinales() { return golesFinales; }
    public int getGolesContra() { return golesContra; }
    public int getDifGoles() { return DifGoles; }
    public int getPuntos() { return puntos; }
}
