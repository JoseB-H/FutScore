package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "apuestas")
public class Apuesta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String estado;
    private Long matchId;
    private String resultado;
    private Double monto;
    private String golesTotales;
    private String tarjetasAmarillas;
    private boolean penal;
    private String corners;
    private boolean ambosMarcan;
    private String quienAnotaPrimero;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    // Getters y setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getMatchId() { return matchId; }
    public void setMatchId(Long matchId) { this.matchId = matchId; }

    public String getResultado() { return resultado; }
    public void setResultado(String resultado) { this.resultado = resultado; }

    public Double getMonto() { return monto; }
    public void setMonto(Double monto) { this.monto = monto; }

    public String getGolesTotales() { return golesTotales; }
    public void setGolesTotales(String golesTotales) { this.golesTotales = golesTotales; }

    public String getTarjetasAmarillas() { return tarjetasAmarillas; }
    public void setTarjetasAmarillas(String tarjetasAmarillas) { this.tarjetasAmarillas = tarjetasAmarillas; }

    public boolean isPenal() { return penal; }
    public void setPenal(boolean penal) { this.penal = penal; }

    public String getCorners() { return corners; }
    public void setCorners(String corners) { this.corners = corners; }

    public boolean isAmbosMarcan() { return ambosMarcan; }
    public void setAmbosMarcan(boolean ambosMarcan) { this.ambosMarcan = ambosMarcan; }

    public String getQuienAnotaPrimero() { return quienAnotaPrimero; }
    public void setQuienAnotaPrimero(String quienAnotaPrimero) { this.quienAnotaPrimero = quienAnotaPrimero; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
}