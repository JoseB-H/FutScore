
package com.example.demo.repository;

import java.util.*;
import com.example.demo.model.Match;
import org.springframework.stereotype.Repository;

@Repository
public class MatchRepository {
    private final List<Match> matches = new ArrayList<>();

    public MatchRepository() {
        // Datos de ejemplo
        matches.add(new Match(1L, "Perú", "Brasil", "2025-06-15", 2.5, 3.0, 1.8, "Pendiente", "Copa América"));
        matches.add(new Match(2L, "Argentina", "Chile", "2025-06-16", 2.2, 2.9, 2.0, "Pendiente", "Copa América"));
        matches.add(new Match(3L, "Colombia", "Bolivia", "2025-06-16", 2.2, 2.9, 2.0, "Pendiente", "Copa América"));
        matches.add(new Match(4L, "Paraguay", "Venezuela", "2025-06-16", 2.2, 2.9, 2.0, "Pendiente", "Copa América"));
        matches.add(new Match(5L, "Ecuador", "Uruguay", "2025-06-16", 2.2, 2.9, 2.0, "Pendiente", "Copa América"));
    }

    public List<Match> findAll() {
        return matches;
    }

    public Match findById(Long id) {
        return matches.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }
}
