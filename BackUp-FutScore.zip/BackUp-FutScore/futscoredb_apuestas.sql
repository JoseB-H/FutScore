-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: futscoredb
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apuestas`
--

DROP TABLE IF EXISTS `apuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apuestas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `match_id` bigint DEFAULT NULL,
  `resultado` varchar(255) DEFAULT NULL,
  `goles_totales` varchar(255) DEFAULT NULL,
  `tarjetas_amarillas` varchar(255) DEFAULT NULL,
  `penal` tinyint(1) DEFAULT NULL,
  `corners` varchar(255) DEFAULT NULL,
  `ambos_marcan` tinyint(1) DEFAULT NULL,
  `quien_anota_primero` varchar(255) DEFAULT NULL,
  `monto` double DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `usuario_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKilt8a4kyy9lcrt5ooftmvp92f` (`usuario_id`),
  CONSTRAINT `FKilt8a4kyy9lcrt5ooftmvp92f` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apuestas`
--

LOCK TABLES `apuestas` WRITE;
/*!40000 ALTER TABLE `apuestas` DISABLE KEYS */;
INSERT INTO `apuestas` VALUES (21,1,'Perú','mas 0.5','mas 0.5',1,'mas 7.5',1,'equipoA',100,NULL,11),(22,1,'Brasil','mas 0.5','mas 0.5',1,'mas 7.5',1,'equipoA',12000,NULL,10),(23,3,'Bolivia','mas 0.5','mas 0.5',1,'mas 7.5',1,'equipoA',100,NULL,13),(24,1,'Empate','mas 0.5','mas 0.5',1,'mas 7.5',1,'equipoA',12000,NULL,10),(25,5,'Ecuador','mas 0.5','mas 0.5',0,'mas 7.5',1,'equipoA',12000,NULL,11);
/*!40000 ALTER TABLE `apuestas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-19  1:53:30
